index=function(req,res){
	res.send('Welcome to the home page');
}

module.exports.index=index;
