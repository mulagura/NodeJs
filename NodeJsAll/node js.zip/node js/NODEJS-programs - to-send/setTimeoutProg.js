setTimeout(function() {
	console.log("This function will be called in 3 seconds");
},3000);

console.log("Program Started.....");
