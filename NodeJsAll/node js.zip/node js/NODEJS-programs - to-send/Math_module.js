var maxTime=1000;
var name="Math Module";
var city="Bangalore";

var subtract=function(i,j)
{
	return i-j;
}

module.exports.subtract=subtract;
module.exports.modulename=name;
module.exports.maxTime=maxTime;

