console.log(process.env);
console.log();
console.log(process.pid);
console.log();
console.log(process.cwd());
