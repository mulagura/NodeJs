var math_module=require("./Math_module");

var retval=math_module.subtract(10,7);

console.log("The difference is:"+retval);
console.log("Name is:"+math_module.modulename);
console.log("Maxtime is:"+math_module.maxTime);
console.log("City is:"+math_module.city);

