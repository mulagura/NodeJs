var os=require('os');
console.log(os.hostname());
console.log(os.tmpDir());
console.log(os.totalmem());

